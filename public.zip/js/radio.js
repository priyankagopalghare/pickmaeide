 $(function () {
        $("input[name='freq']").click(function () {
            if ($("#freq_daily").is(":checked")) {
                $("#dvPassport").show();
                $("#test").show();
            } else {
                $("#dvPassport").hide();
                $("#test").hide();

            }
        });
    });
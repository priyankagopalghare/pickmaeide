 google.maps.event.addDomListener(window,'load',intilize);
function intilize()
        {
            var autocomplete_f=new google.maps.places.Autocomplete(document.getElementById('textautocompletef'));
            var autocomplete_t=new google.maps.places.Autocomplete(document.getElementById('textautocompletet'));
        };
 /* function getParams(){
  var idx = document.URL.indexOf('?');
  var params = new Array();
  if (idx != -1) {
    var pairs = document.URL.substring(idx+1, document.URL.length).split('&');
  for (var i=0; i<pairs.length; i++){
    nameVal = pairs[i].split('=');
    params[nameVal[0]] = nameVal[1];
    }
  }
  return params;
 }
params = getParams();
start = unescape(params["input_from"]);
end = unescape(params["input_to"]);
*/
start=document.getElementById("start1").value;
start=document.getElementById("end1").value;

document.getElementById("start").value=start;
document.getElementById("end").value=end;
